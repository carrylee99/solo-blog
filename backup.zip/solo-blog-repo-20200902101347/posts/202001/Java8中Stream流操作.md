title: Java8中Stream流操作
date: '2020-01-15 15:10:36'
updated: '2020-01-15 15:10:36'
tags: [java8, stream]
permalink: /articles/2020/01/15/1579072236046.html
---
持续更新：

获取集合中某个属性的集合
List<String> orders=list.stream().map(User::getOrder).collect(Collectors.toList());   

筛选出集合中符合条件的项
List<User> userList = User.stream().filter(item -> item.getId() == 0).collect(Collectors.toList());   

排序、跳过、分页
userList.stream().sorted(Comparator.comparing(User::getId)).skip(10).limit(10).collect(Collectors.toList());

按某个字段分组并排除掉为 null的
Map<Long, List<User>> idMap = list.stream().filter(a -> a.getId() !=null).collect(Collectors.groupingBy(TransportJobStatistics::getId));
