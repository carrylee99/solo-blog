title: java用poi实现word导出
date: '2020-08-21 09:52:36'
updated: '2020-08-21 10:27:56'
tags: [导出word]
permalink: /articles/2020/08/21/1597974756527.html
---
![](https://b3logfile.com/bing/20190327.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 



### 业务：需要把活动详情按模板导出成word文档。

![image.png](https://b3logfile.com/file/2020/08/image-e73c5ba9.png)

#### 选方案：

目前市面上用的比较多的有几种。

1. poi-tl
2. poi
3. easypoi
4. freemaker
5. 还有一种是以 mht的格式导出。

* 对比：

1：我最开始是准备用这种的，Poi-tl是开源的基于apache-poi封装的模板引擎，支持自定义插件，能做很多事情。默认的几个插件用起来很方便。

这是官方文档

http://deepoove.com/poi-tl/#_why_poi_tl

可是当我实现了业务及功能的时候，发现导出的时候会报 类找不到这个错。到官网上一查才发现

![image.png](https://b3logfile.com/file/2020/08/image-9d0c28f3.png)

但是因为我司之前已经引用了poi 3.9的版本。不能升版本上去。（升的话，CellStyle这个类里有些属性会找不到，导致导出excel那边功能会报错。）

所以最后放弃了poi-tl这个方案。

2. 这是最后选择的方案，后面讲。
3. easypoi 是 阿里开源的轻量级的文档操作框架，但是不支持富文本，所以也没选用这种。
4. 只支持文本，需要维护xml，很难迭代。
5. 这种的了解不多，但是很老的方案。

所以最后还是选择了 apache的poi 方案。

#### 开始开发

参考资料：

https://www.jianshu.com/p/6603b1ea3ad1

首先先准备一个模板文件。导出word的思路是 读取模板文件，渲染数据到一个新的文件，导出流到浏览器下载。

![image.png](https://b3logfile.com/file/2020/08/image-3d42cef2.png)

1. controller层代码

```
（ps：这一段是放配置文件里的，我偷懒直接放这里了。）
#活动台账导出模板文件存放路径

activityExportTemp=/root/NEAP-docker-compose/templates/

// 模板文件名和新生成的文件名


private static String oldFileName = "activityExportTemplate.docx";

private static String newFileName = "activityDetailExport.docx";


// 文件路径，配置在 application.properties文件中。

@Value("${activityExportTemp}")

public String tempUrl;


    @ApiOperation(value = "活动台账导出")

    @PostMapping("/activityDetailExport/{id}")

    public void exportWord(@PathVariable Long id, HttpServletRequest request, HttpServletResponse response) throws IOException {


        // 获取活动详情

        RestResult<ActivityVO> activityVORestResult = activityService.getActivity(id);

        ActivityVO activityVO = activityVORestResult.getResultData();

        Map<String, String> renderData = new HashMap<>();

        // 活动名称
        renderData.put("name", activityVO.getName());

        // 活动时间
        renderData.put("time", formatDate.format(activityVO.getStartTime()));

        // 活动地点
        renderData.put("address", activityVO.getAddress());

        // 参与人数
        String peopleStr = activityVO.getSignInCount() + "/" + activityVO.getPeopleLimit();
        renderData.put("people", peopleStr);

        // 活动负责人
        renderData.put("principalName", activityVO.getPrincipalName());

        // 志愿者
        renderData.put("volunteer", activityVO.getVolunteer());

        // 活动性质
        renderData.put("propertyName", activityVO.getPropertyName());

        // 活动类别
        renderData.put("categoryName", activityVO.getCategoryName());

        String textFromHtml = "";
        if (StringUtil.isNotEmpty(activityVO.getRecord())) {

            textFromHtml = HtmlUtil.getTextFromHtml(activityVO.getRecord());
        }

        // 活动负责人
        renderData.put("abc", textFromHtml);

        // 活动类别
        NsCoreDictionaryVo categoryDictionary = getDictionary("activityCategory", activityVO.getOrganizationId());

        List<NsCoreDictionaryitemVo> categoryDictionaryVos = categoryDictionary.getDictionaryitemVos();

        String categoryStr = categoryDictionaryVos.stream().map(NsCoreDictionaryitemVo::getDictionaryitemItemname).collect(Collectors.joining("/"));

        categoryStr = "活动类别(" + categoryStr + ")";

        renderData.put("categoryStr", categoryStr);

        // 活动性质
        NsCoreDictionaryVo natureDictionary = getDictionary("activityNature", activityVO.getOrganizationId());

        List<NsCoreDictionaryitemVo> natureDictionaryVos = natureDictionary.getDictionaryitemVos();

        String natureStr = natureDictionaryVos.stream().map(NsCoreDictionaryitemVo::getDictionaryitemItemname).collect(Collectors.joining("/"));

        natureStr = "活动性质(" + natureStr + ")";

        renderData.put("propertyStr", natureStr);

        // 文件名
        OrgVO orgVO = orgService.getOrgByOrgId(activityVO.getOrganizationId());

        String orgName = orgVO.getOrgName();
        String activityTime = formatDate.format(activityVO.getStartTime());
        String activityName = activityVO.getName();
        String title = orgName + activityTime + activityName;


        // 生成新的文件
        File file = ExportWordUtil.changWordFile(oldFileName, newUrl, renderData, null);

        // 下载文件到浏览器
        ExportWordUtil.downFile(request,response,title,file);
    }
```

#### 导出工具类

```
package com.newsee.elder.common.utils;

/**

* @description: * POI导出word文档 无插件

* @author: lee

* @date: 2020/6/22/0022 14:27

**/


import lombok.extern.slf4j.Slf4j;

import org.apache.poi.POIXMLDocument;

import org.apache.poi.xwpf.usermodel.*;

import org.springframework.core.io.ClassPathResource;



import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import java.io.*;

import java.net.URLEncoder;

import java.util.*;



/**

* POI导出word文档 无插件

* Created by lxh on 2020/6/23.

*/

@Slf4j

public class ExportWordUtil {



    /**

     * 根据模板生成新word文档

     * 判断表格是需要替换还是需要插入，判断逻辑有$为替换，表格无$为插入

     * @param inputUrl 模板存放地址

     * @param outputUrl 新文档存放地址

     * @param textMap 需要替换的信息集合

     * @param tableList 需要插入的表格信息集合

     * @return 成功返回true, 失败返回false

     */

    public static boolean changWord(String inputUrl, String outputUrl, Map<String, String> textMap, List<String[]> tableList) {



        //模板转换默认成功

        boolean changeFlag = true;

        try {

            //获取docx解析对象

            XWPFDocument document = new XWPFDocument(POIXMLDocument.openPackage(inputUrl));

            //解析替换文本段落对象

            ExportWordUtil.changeText(document, textMap);

            //解析替换表格对象

            ExportWordUtil.changeTable(document, textMap, tableList);



            //生成新的word

            File file = new File(outputUrl);

            FileOutputStream stream = new FileOutputStream(file);

            document.write(stream);

            stream.close();



        } catch (IOException e) {

            e.printStackTrace();

            changeFlag = false;

        }



        return changeFlag;



    }



    /**

     * 根据模板生成新word文档

     * 判断表格是需要替换还是需要插入，判断逻辑有$为替换，表格无$为插入

     * @param inputUrl 模板存放地址

     * @param outputUrl 新文档存放地址

     * @param textMap 需要替换的信息集合

     * @param tableList 需要插入的表格信息集合

     * @return 返回生成的文件

     */

    public static File changWordFile(String inputUrl, String outputUrl, Map<String, String> textMap, List<String[]> tableList) {



        //模板转换默认成功

        boolean changeFlag = true;

        File file = new File(outputUrl);

        try {

            //获取docx解析对象

//            ClassPathResource classPathResource = new ClassPathResource("activityDetailExportTemp.docx");

            ClassPathResource classPathResource = new ClassPathResource(inputUrl);

            String path = classPathResource.getPath();

            log.info("exportWordUtil--path:===>" + path);

            String url = classPathResource.getURL().toString();

            log.info("exportWordUtil--url:===>" + url);

            InputStream inputStream = classPathResource.getInputStream();



            XWPFDocument document = new XWPFDocument(inputStream);

            //解析替换文本段落对象

            ExportWordUtil.changeText(document, textMap);

            //解析替换表格对象

            ExportWordUtil.changeTable(document, textMap, tableList);



            //生成新的word

            FileOutputStream stream = new FileOutputStream(outputUrl);

            document.write(stream);

            stream.close();



        } catch (IOException e) {

            e.printStackTrace();

            changeFlag = false;

        }

        return file;

    }



    /**

     * 替换段落文本

     * @param document docx解析对象

     * @param textMap 需要替换的信息集合

     */

    public static void changeText(XWPFDocument document, Map<String, String> textMap) {

        //获取段落集合

        List<XWPFParagraph> paragraphs = document.getParagraphs();



        for (XWPFParagraph paragraph : paragraphs) {

            //判断此段落时候需要进行替换

            String text = paragraph.getText();

            if (checkText(text)) {

                List<XWPFRun> runs = paragraph.getRuns();

                for (XWPFRun run : runs) {

                    //替换模板原来位置

                    run.setText(changeValue(run.toString(), textMap), 0);

                }

            }

        }



    }



    /**

     * 替换表格对象方法

     * @param document docx解析对象

     * @param textMap 需要替换的信息集合

     * @param tableList 需要插入的表格信息集合

     */

    public static void changeTable(XWPFDocument document, Map<String, String> textMap,

                                   List<String[]> tableList) {

        //获取表格对象集合

        List<XWPFTable> tables = document.getTables();

        for (int i = 0; i < tables.size(); i++) {

            //只处理行数大于等于2的表格，且不循环表头

            XWPFTable table = tables.get(i);

            if (table.getRows().size() > 1) {

                //判断表格是需要替换还是需要插入，判断逻辑有$为替换，表格无$为插入

                if (checkText(table.getText())) {

                    List<XWPFTableRow> rows = table.getRows();

                    //遍历表格,并替换模板

                    eachTable(rows, textMap);

                } else {

//                  System.out.println("插入"+table.getText());

                    insertTable(table, tableList);

                }

            }

        }

    }



    /**

     * 遍历表格

     * @param rows 表格行对象

     * @param textMap 需要替换的信息集合

     */

    public static void eachTable(List<XWPFTableRow> rows, Map<String, String> textMap) {

        for (XWPFTableRow row : rows) {

            List<XWPFTableCell> cells = row.getTableCells();

            for (XWPFTableCell cell : cells) {

                //判断单元格是否需要替换

                if (checkText(cell.getText())) {

                    List<XWPFParagraph> paragraphs = cell.getParagraphs();

                    for (XWPFParagraph paragraph : paragraphs) {

                        List<XWPFRun> runs = paragraph.getRuns();

                        for (XWPFRun run : runs) {

                            run.setText(changeValue(run.toString(), textMap), 0);

                        }

                    }

                }

            }

        }

    }



    /**

     * 为表格插入数据，行数不够添加新行

     * @param table 需要插入数据的表格

     * @param tableList 插入数据集合

     */

    public static void insertTable(XWPFTable table, List<String[]> tableList) {

        //创建行,根据需要插入的数据添加新行，不处理表头

        for (int i = 1; i < tableList.size(); i++) {

            XWPFTableRow row = table.createRow();

        }

        //遍历表格插入数据

        List<XWPFTableRow> rows = table.getRows();

        for (int i = 1; i < rows.size(); i++) {

            XWPFTableRow newRow = table.getRow(i);

            List<XWPFTableCell> cells = newRow.getTableCells();

            for (int j = 0; j < cells.size(); j++) {

                XWPFTableCell cell = cells.get(j);

                cell.setText(tableList.get(i - 1)[j]);

            }

        }



    }





    /**

     * 判断文本中时候包含$

     * @param text 文本

     * @return 包含返回true, 不包含返回false

     */

    public static boolean checkText(String text) {

        boolean check = false;

        if (text.indexOf("$") != -1) {

            check = true;

        }

        return check;



    }



    /**

     * 匹配传入信息集合与模板

     * @param value 模板需要替换的区域

     * @param textMap 传入信息集合

     * @return 模板需要替换区域信息集合对应值

     */

    public static String changeValue(String value, Map<String, String> textMap) {

        Set<Map.Entry<String, String>> textSets = textMap.entrySet();

        for (Map.Entry<String, String> textSet : textSets) {

            //匹配模板与替换值 格式${key}

            String key = "${" + textSet.getKey() + "}";

            if (value.indexOf(key) != -1) {

                value = textSet.getValue();

            }

        }

        //模板未匹配到区域替换为空

        if (checkText(value)) {

            value = "";

        }

        return value;

    }



    public static void main(String[] args) {

        //模板文件地址

        String inputUrl = "C:\\Users\\zhihe\\Desktop\\demo\\001.docx";

        //新生产的模板文件

        String outputUrl = "C:\\Users\\zhihe\\Desktop\\demo\\test.docx";



        Map<String, String> testMap = new HashMap<String, String>();

        testMap.put("name", "小明");

        testMap.put("sex", "男");

        testMap.put("address", "软件园");

        testMap.put("phone", "88888888");



        List<String[]> testList = new ArrayList<String[]>();

        testList.add(new String[]{"1", "1AA", "1BB", "1CC"});

        testList.add(new String[]{"2", "2AA", "2BB", "2CC"});

        testList.add(new String[]{"3", "3AA", "3BB", "3CC"});

        testList.add(new String[]{"4", "4AA", "4BB", "4CC"});



        ExportWordUtil.changWord(inputUrl, outputUrl, testMap, testList);

    }





    public static void downFile(HttpServletRequest request, HttpServletResponse response, String filename, File file) throws IOException {

        //  文件存在才下载

        if (file.exists()) {

            OutputStream out = null;

            FileInputStream in = null;

            try {

                // 1.读取要下载的内容

                in = new FileInputStream(file);



                // 2. 告诉浏览器下载的方式以及一些设置

                // 解决文件名乱码问题，获取浏览器类型，转换对应文件名编码格式，IE要求文件名必须是utf-8, firefo要求是iso-8859-1编码

                String agent = request.getHeader("user-agent");

                if (agent.contains("FireFox")) {

                    filename = new String(filename.getBytes("UTF-8"), "iso-8859-1");

                } else {

                    filename = URLEncoder.encode(filename, "UTF-8");

                }

                // 设置下载文件的mineType，告诉浏览器下载文件类型

                String mineType = request.getServletContext().getMimeType(filename);

                response.setContentType(mineType);

                /**

                 * 这里需要注意的是，架构组那边支持流下载的请求头格式只有四种。

                 * 1、application/octet-stream;charset=UTF-8

                 * 2、application/vnd.ms-excel;charset=UTF-8

                 * 3、application/x-msdownload

                 * 4、application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8

                 * */

                // 设置一个响应头，无论是否被浏览器解析，都下载

                response.setContentType("application/octet-stream;charset=UTF-8");//导出word格式

                response.setHeader("Access-Control-Expose-Headers","downloadFileName, Content-Disposition");

                response.addHeader("Content-Disposition", "attachment;filename=" +

                        new String((filename + ".docx").getBytes(),

                                "UTF-8"));

                response.setHeader("downloadFileName", URLEncoder.encode((filename + ".docx"), "UTF-8"));

                // 将要下载的文件内容通过输出流写到浏览器

                out = response.getOutputStream();

                int len = 0;

                byte[] buffer = new byte[1024];

                while ((len = in.read(buffer)) > 0) {

                    out.write(buffer, 0, len);

                }

            } catch (IOException e) {

                e.printStackTrace();

            } finally {

                if (out != null) {

                    out.close();

                }

                if (in != null) {

                    in.close();

                }

                file.deleteOnExit();

            }

        }

    }





    /**

     * 通过文件名获取文件完整路径

     * @param fileName

     * @return 文件完整路径

     */

    public static String getUrl(String fileName) {

        String property = System.getProperty("file.separator");

        File file = new File(fileName);

        String filePath = null;

        filePath = file.getAbsolutePath();

        return filePath;

    }

}
```

### 代码写好了。现在记录一些坑。

#### 模板文件找不到

因为我们是把模板文件放在 src/main/resources的目录下。jar包编译之后，通过类加载器和文件路径一直找不到文件。

这几种都能拿到路径，但是解析都还是不行。

```
URL url = this.getClass().getClassLoader().getResource("activityDetailExportTemp.docx");

String path = Thread.currentThread().getContextClassLoader().getResource("").getPath()+oldFileName;
```

最后使用的是。  new ClassPathResource("activityExportTemplate.docx") 的方式拿到了流。 注意，这里括号内直接加resouces下的文件名就好了。如果文件还在resource的下一级，那就加上那一级路径就好了。

```
ClassPathResource classPathResource = new ClassPathResource(oldFileName);

InputStream inputStream = classPathResource.getInputStream();
```

这里中间还有点小插曲，因为一直找不到文件，就尝试把文件直接放到linux上的绝对路径下。 /root/tempaltes  这种路径下。

但是由于我们的是 docker容器部署的，docker内部是一个小的Linux系统。所以直接用 绝对路径也不行。

需要在dockerFile 编译的时候 把宿主机里的文件 挂载到 docker容器里去。 然后通过容器的路径去找到文件。

#### 成功导出了之后，只是返回的是流，但是并没有调起浏览器的保存文件的事件。

这种一般就是请求头的  contentType 的设置问题。

和前端沟通了之后，发现是架构组那边限制了请求头的类型，只支持四种请求头。所以用了其中一种就好了。

### 总结

这一次导出word的需求是弄好了，其实主要还是方案选型的问题。 如果选对方案了，实际开发代码其实不复杂的，难的就是网上的资料文档不多，仅有的一些资料参差不齐，可能需要我们自己试了以后再来比较是否满足业务需要。。。

