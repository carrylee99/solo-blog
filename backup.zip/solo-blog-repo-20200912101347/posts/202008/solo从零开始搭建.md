title: solo从零开始搭建
date: '2020-08-20 20:07:19'
updated: '2020-08-20 22:12:21'
tags: [Solo, 博客]
permalink: /articles/2020/08/20/1597925238935.html
---
![](https://b3logfile.com/bing/20190628.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

具体的详细的步骤可以参考这篇文章，不仅内容非常详细，而且评论里也有很多小伙伴发出了问题并找到了解决办法的可以参考下
[https://hacpai.com/article/1565021959471](https://)

### 这篇文章主要是记录一下自己搭建的过程中遇到的一些坑。

##### 安装solo镜像的时候端口冲突

教程里的是8080，很多情况下8080都被占用了。所以我们可以改成我们自己的端口，随便改，我这里改成了8081。没有关系的。 代码会放到后面。

##### 安装ssl证书，配置nginx的时候

配置里是写的 /ssl/**************   这里的/ssl 的路径指的是 容器内部的路径，并不是宿主机linux里的路径，大家按着教程来的时候只修改后面的具体名字就好了，不用改路径就不会有问题了。

##### nginx最终的配置是什么样的

因为教程里是一步一步来的，有时候这里配一下，那里配一下。最后也没有贴个完整版的配置代码，就会导致很多问题，例如 404啊，或者根本找不到地址啊，本人在这里就耽搁了好几个小时。最终的配置文件也会放到后面。

# # 具体的步骤代码

```
创建nginx的文件路径
mkdir  dockerData/nginx
mkdir  dockerData/nginx/conf  
mkdir  dockerData/nginx/logs  
mkdir  dockerData/nginx/www  
mkdir  dockerData/nginx/ssl
```

启动nginx：

```
docker  run  -d  -p  80:80  -p  443:443  --name  nginx  \
-v  /dockerData/nginx/conf/nginx.conf:/etc/nginx/nginx.conf  \
-v  /dockerData/nginx/conf/conf.d:/etc/nginx/conf.d  \
-v  /dockerData/nginx/ssl:/ssl/  \
-v  /dockerData/nginx/www:/usr/share/nginx/html  \
-v  /dockerData/nginx/logs:/var/log/nginx  nginx
```

conf.d/default.conf配置文件（**最终能跑起来的整个文件都在这了。**）：

```
server {
    listen       443;
    listen  [::]:80;
    server_name  www.liandacj.com;  #自己的域名
    ssl on;    # 开启ssl也就是 https

    ssl_certificate /ssl/www.liandacj.com.crt;  # ssl 证书目录
    ssl_certificate_key /ssl/www.liandacj.com.key;
    ssl_session_timeout 5m;
    ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE;
    ssl_prefer_server_ciphers on;

    #charset koi8-r;
    #access_log  /var/log/nginx/host.access.log  main;

    location / {
	proxy_pass http://backend$request_uri;
        proxy_set_header  Host $http_host;
        proxy_set_header  X-Real-IP $remote_addr;
        #root   /usr/share/nginx/html;
        #index  index.html index.htm;
    }

    #error_page  404              /404.html;

    # redirect server error pages to the static page /50x.html
    #
    error_page   500 502 503 504  /50x.html;
    location = /50x.html {
        root   /usr/share/nginx/html;
    }

    # proxy the PHP scripts to Apache listening on 127.0.0.1:80
    #
    #location ~ \.php$ {
    #    proxy_pass   http://127.0.0.1;
    #}

    # pass the PHP scripts to FastCGI server listening on 127.0.0.1:9000
    #
    #location ~ \.php$ {
    #    root           html;
    #    fastcgi_pass   127.0.0.1:9000;
    #    fastcgi_index  index.php;
    #    fastcgi_param  SCRIPT_FILENAME  /scripts$fastcgi_script_name;
    #    include        fastcgi_params;
    #}

    # deny access to .htaccess files, if Apache's document root
    # concurs with nginx's one
    #
    #location ~ /\.ht {
    #    deny  all;
    #}
}
upstream backend{
    server 106.13.122.212:8081;    #这里的端口就是启动solo的时候设置的端口。
#这里还有一个巨坑！！！  教程里写的是 localhost  ，我一开始就一直出不来，一直404，后来改成具体的ip就好了。似乎是 localhos和服务器具体ip和 127.0.0.1  这三个其实都是不一样的。
}
```

启动solo代码（就是在这里设置端口号）：

```
docker  run  --detach  --name  solo  --network=host  \
--env  RUNTIME_DB="MYSQL"  \
--env  JDBC_USERNAME="root"  \
--env  JDBC_PASSWORD=""  \
--env  JDBC_DRIVER="com.mysql.cj.jdbc.Driver"  \
--env  JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC"  \
b3log/solo  --listen_port=8081  --server_scheme=https  --server_host=www.liandacj.com  --server_port=
```

docker的一些命令：

```
docker ps -a  #查看容器状态
docker stop 容器ID/容器名字  #停止容器
docker rm 容器ID/容器名字  #删除容器
docker rmi 镜像ID   #删除镜像

docker restart 容器ID/容器名字  #重启容器

docker logs 容器ID/容器名字   #查看容器日志

docker exec -it 容器ID /bin/bash   #进入容器内部（进入之后就像是另一个Linux一样）
```

## 升级

直接用D大的脚本 [https://github.com/88250/solo/edit/master/scripts/docker-restart.sh](https://)

```
#!/bin/bash

#
# Solo docker 更新重启脚本
#
# 1. 请注意修改参数
# 2. 可将该脚本加入 crontab，每日凌晨运行来实现自动更新
#

restart_solo(){
	docker stop solo
	docker rm solo
	docker run --detach --name solo --network=host \
	--env RUNTIME_DB="MYSQL" \
	--env JDBC_USERNAME="root" \
	--env JDBC_PASSWORD="123456" \
	--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
	--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
       	b3log/solo --listen_port=8080 --server_scheme=http --server_host=localhost
}

update_solo(){
  echo "Pulling Solo's image"
	isUpdate=$(docker pull b3log/solo | grep "Downloaded")
	if [[ -z $isUpdate ]]
	then
		echo "Solo is up to date"
	else
		restart_solo >> /dev/null 2>&1
		echo "Restarted Solo"
	fi
}

# 检查当前容器状态，如果状态正常进行升级操作，否则重新进行部署
update_and_test_service(){
	isCrash=$(docker ps | grep "b3log/solo")
	if [[ -z $isCrash ]]
	then
		echo "Solo's status is unexpected, trying to restart it"
		docker pull b3log/solo
		restart_solo
		sleep 5
		isSecondCrash=$(docker ps | grep "b3log/solo")
		if [[ -z $isSecondCrash ]]
		then
			echo "Failed to restart Solo, please check logs via 'docker logs solo'"
		fi
	else
		update_solo
	fi
}

update_and_test_service
```

